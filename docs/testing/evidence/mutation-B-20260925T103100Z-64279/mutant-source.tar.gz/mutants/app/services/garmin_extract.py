"""Pure Garmin payload -> metric extraction. Garmin's unofficial API has no
schema guarantee, so each value is looked up via multiple candidate key
paths and validated against a plausible range before being trusted. Every
extraction reports its outcome (`ok`/`missing`/`implausible`) instead of
just returning `None`. Pure functions only — no DB, no network.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict


@dataclass
class ExtractedMetric:
    value: float | None
    payload: Any
    status: str  # "ok" | "missing" | "implausible"
    detail: str | None = None


# Plausibility bounds (inclusive). A value outside these is rejected rather
# than persisted, since a wrong-but-numeric value is worse than none (it
# silently corrupts averages, readiness, targets, etc.)
PLAUSIBLE_RANGES: dict[str, tuple[float, float]] = {
    "sleep": (0.0, 16.0),  # hours
    "sleep_score": (0.0, 100.0),
    "hrv": (1.0, 300.0),  # ms (rMSSD), 0 is never a real reading
    "hrv_weekly": (1.0, 300.0),
    "body_battery": (0.0, 100.0),
    "stress_daily": (0.0, 100.0),
    "resting_hr": (20.0, 120.0),  # bpm
    "steps": (0.0, 100_000.0),
    "calories": (0.0, 10_000.0),
    "training_readiness": (0.0, 100.0),
    "vo2max": (20.0, 90.0),
}
mutants_x__dig__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__dig__mutmut)
def _dig(d: Any, *keys: str) -> Any:
    cur = d
    for k in keys:
        if not isinstance(cur, dict) or k not in cur:
            return None
        cur = cur[k]
    return cur


def x__dig__mutmut_orig(d: Any, *keys: str) -> Any:
    cur = d
    for k in keys:
        if not isinstance(cur, dict) or k not in cur:
            return None
        cur = cur[k]
    return cur


def x__dig__mutmut_1(d: Any, *keys: str) -> Any:
    cur = None
    for k in keys:
        if not isinstance(cur, dict) or k not in cur:
            return None
        cur = cur[k]
    return cur


def x__dig__mutmut_2(d: Any, *keys: str) -> Any:
    cur = d
    for k in keys:
        if not isinstance(cur, dict) and k not in cur:
            return None
        cur = cur[k]
    return cur


def x__dig__mutmut_3(d: Any, *keys: str) -> Any:
    cur = d
    for k in keys:
        if isinstance(cur, dict) or k not in cur:
            return None
        cur = cur[k]
    return cur


def x__dig__mutmut_4(d: Any, *keys: str) -> Any:
    cur = d
    for k in keys:
        if not isinstance(cur, dict) or k in cur:
            return None
        cur = cur[k]
    return cur


def x__dig__mutmut_5(d: Any, *keys: str) -> Any:
    cur = d
    for k in keys:
        if not isinstance(cur, dict) or k not in cur:
            return None
        cur = None
    return cur

mutants_x__dig__mutmut['_mutmut_orig'] = x__dig__mutmut_orig # type: ignore # mutmut generated
mutants_x__dig__mutmut['x__dig__mutmut_1'] = x__dig__mutmut_1 # type: ignore # mutmut generated
mutants_x__dig__mutmut['x__dig__mutmut_2'] = x__dig__mutmut_2 # type: ignore # mutmut generated
mutants_x__dig__mutmut['x__dig__mutmut_3'] = x__dig__mutmut_3 # type: ignore # mutmut generated
mutants_x__dig__mutmut['x__dig__mutmut_4'] = x__dig__mutmut_4 # type: ignore # mutmut generated
mutants_x__dig__mutmut['x__dig__mutmut_5'] = x__dig__mutmut_5 # type: ignore # mutmut generated
mutants_x__first__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__first__mutmut)
def _first(d: Any, *paths: tuple[str, ...]) -> Any:
    """Return the first non-None value found at any of the candidate paths."""
    for path in paths:
        v = _dig(d, *path)
        if v is not None:
            return v
    return None


def x__first__mutmut_orig(d: Any, *paths: tuple[str, ...]) -> Any:
    """Return the first non-None value found at any of the candidate paths."""
    for path in paths:
        v = _dig(d, *path)
        if v is not None:
            return v
    return None


def x__first__mutmut_1(d: Any, *paths: tuple[str, ...]) -> Any:
    """Return the first non-None value found at any of the candidate paths."""
    for path in paths:
        v = None
        if v is not None:
            return v
    return None


def x__first__mutmut_2(d: Any, *paths: tuple[str, ...]) -> Any:
    """Return the first non-None value found at any of the candidate paths."""
    for path in paths:
        v = _dig(None, *path)
        if v is not None:
            return v
    return None


def x__first__mutmut_3(d: Any, *paths: tuple[str, ...]) -> Any:
    """Return the first non-None value found at any of the candidate paths."""
    for path in paths:
        v = _dig(*path)
        if v is not None:
            return v
    return None


def x__first__mutmut_4(d: Any, *paths: tuple[str, ...]) -> Any:
    """Return the first non-None value found at any of the candidate paths."""
    for path in paths:
        v = _dig(d, )
        if v is not None:
            return v
    return None


def x__first__mutmut_5(d: Any, *paths: tuple[str, ...]) -> Any:
    """Return the first non-None value found at any of the candidate paths."""
    for path in paths:
        v = _dig(d, *path)
        if v is None:
            return v
    return None

mutants_x__first__mutmut['_mutmut_orig'] = x__first__mutmut_orig # type: ignore # mutmut generated
mutants_x__first__mutmut['x__first__mutmut_1'] = x__first__mutmut_1 # type: ignore # mutmut generated
mutants_x__first__mutmut['x__first__mutmut_2'] = x__first__mutmut_2 # type: ignore # mutmut generated
mutants_x__first__mutmut['x__first__mutmut_3'] = x__first__mutmut_3 # type: ignore # mutmut generated
mutants_x__first__mutmut['x__first__mutmut_4'] = x__first__mutmut_4 # type: ignore # mutmut generated
mutants_x__first__mutmut['x__first__mutmut_5'] = x__first__mutmut_5 # type: ignore # mutmut generated
mutants_x__build__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__build__mutmut)
def _build(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_orig(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_1(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is not None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_2(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, None, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_3(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, None, "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_4(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", None)
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_5(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_6(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_7(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_8(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", )
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_9(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "XXmissingXX", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_10(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "MISSING", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_11(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "XXno value at any known key-pathXX")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_12(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "NO VALUE AT ANY KNOWN KEY-PATH")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_13(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = None
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_14(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(None)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_15(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, None, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_16(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, None, f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_17(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", None)
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_18(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_19(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_20(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_21(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", )
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_22(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "XXmissingXX", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_23(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "MISSING", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_24(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = None
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_25(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(None)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_26(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None or not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_27(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_28(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_29(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[1] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_30(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] < value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_31(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value < bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_32(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[2]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_33(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            None,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_34(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            None,
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_35(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            None,
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_36(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_37(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_38(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_39(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_40(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "XXimplausibleXX",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_41(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "IMPLAUSIBLE",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_42(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[1]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_43(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[2]}]",
        )
    return ExtractedMetric(value, payload, "ok", None)


def x__build__mutmut_44(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(None, payload, "ok", None)


def x__build__mutmut_45(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, None, "ok", None)


def x__build__mutmut_46(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, None, None)


def x__build__mutmut_47(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(payload, "ok", None)


def x__build__mutmut_48(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, "ok", None)


def x__build__mutmut_49(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, None)


def x__build__mutmut_50(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "ok", )


def x__build__mutmut_51(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "XXokXX", None)


def x__build__mutmut_52(kind: str, raw_value: Any, payload: Any) -> ExtractedMetric:
    if raw_value is None:
        return ExtractedMetric(None, payload, "missing", "no value at any known key-path")
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return ExtractedMetric(None, payload, "missing", f"non-numeric value: {raw_value!r}")
    bounds = PLAUSIBLE_RANGES.get(kind)
    if bounds is not None and not (bounds[0] <= value <= bounds[1]):
        return ExtractedMetric(
            None,
            payload,
            "implausible",
            f"{value} outside plausible range [{bounds[0]}, {bounds[1]}]",
        )
    return ExtractedMetric(value, payload, "OK", None)

mutants_x__build__mutmut['_mutmut_orig'] = x__build__mutmut_orig # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_1'] = x__build__mutmut_1 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_2'] = x__build__mutmut_2 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_3'] = x__build__mutmut_3 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_4'] = x__build__mutmut_4 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_5'] = x__build__mutmut_5 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_6'] = x__build__mutmut_6 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_7'] = x__build__mutmut_7 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_8'] = x__build__mutmut_8 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_9'] = x__build__mutmut_9 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_10'] = x__build__mutmut_10 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_11'] = x__build__mutmut_11 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_12'] = x__build__mutmut_12 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_13'] = x__build__mutmut_13 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_14'] = x__build__mutmut_14 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_15'] = x__build__mutmut_15 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_16'] = x__build__mutmut_16 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_17'] = x__build__mutmut_17 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_18'] = x__build__mutmut_18 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_19'] = x__build__mutmut_19 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_20'] = x__build__mutmut_20 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_21'] = x__build__mutmut_21 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_22'] = x__build__mutmut_22 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_23'] = x__build__mutmut_23 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_24'] = x__build__mutmut_24 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_25'] = x__build__mutmut_25 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_26'] = x__build__mutmut_26 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_27'] = x__build__mutmut_27 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_28'] = x__build__mutmut_28 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_29'] = x__build__mutmut_29 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_30'] = x__build__mutmut_30 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_31'] = x__build__mutmut_31 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_32'] = x__build__mutmut_32 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_33'] = x__build__mutmut_33 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_34'] = x__build__mutmut_34 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_35'] = x__build__mutmut_35 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_36'] = x__build__mutmut_36 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_37'] = x__build__mutmut_37 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_38'] = x__build__mutmut_38 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_39'] = x__build__mutmut_39 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_40'] = x__build__mutmut_40 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_41'] = x__build__mutmut_41 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_42'] = x__build__mutmut_42 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_43'] = x__build__mutmut_43 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_44'] = x__build__mutmut_44 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_45'] = x__build__mutmut_45 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_46'] = x__build__mutmut_46 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_47'] = x__build__mutmut_47 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_48'] = x__build__mutmut_48 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_49'] = x__build__mutmut_49 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_50'] = x__build__mutmut_50 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_51'] = x__build__mutmut_51 # type: ignore # mutmut generated
mutants_x__build__mutmut['x__build__mutmut_52'] = x__build__mutmut_52 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut: MutantDict = {}  # type: ignore


# ── per-metric extractors ──────────────────────────────────────────────
@_mutmut_mutated(mutants_x_extract_sleep__mutmut)
def extract_sleep(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_orig(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_1(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = None
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_2(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") and {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_3(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get(None) or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_4(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("XXsleepXX") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_5(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("SLEEP") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_6(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = None
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_7(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        None,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_8(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        None,
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_9(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        None,
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_10(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_11(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_12(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_13(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("XXdailySleepDTOXX", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_14(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailysleepdto", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_15(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("DAILYSLEEPDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_16(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "XXsleepTimeSecondsXX"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_17(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleeptimeseconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_18(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "SLEEPTIMESECONDS"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_19(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("XXsleepTimeSecondsXX",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_20(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleeptimeseconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_21(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("SLEEPTIMESECONDS",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_22(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_23(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if (isinstance(seconds, (int, float))) and False else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_24(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if (isinstance(seconds, (int, float))) or True else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_25(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds * 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_26(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3601.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_27(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build(None, hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_28(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", None, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_29(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, None)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_30(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build(hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_31(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_32(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("sleep", hours, )


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_33(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("XXsleepXX", hours, sleep)


# ── per-metric extractors ──────────────────────────────────────────────
def x_extract_sleep__mutmut_34(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    seconds = _first(
        sleep,
        ("dailySleepDTO", "sleepTimeSeconds"),
        ("sleepTimeSeconds",),
    )
    hours = seconds / 3600.0 if isinstance(seconds, (int, float)) else None
    return _build("SLEEP", hours, sleep)

mutants_x_extract_sleep__mutmut['_mutmut_orig'] = x_extract_sleep__mutmut_orig # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_1'] = x_extract_sleep__mutmut_1 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_2'] = x_extract_sleep__mutmut_2 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_3'] = x_extract_sleep__mutmut_3 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_4'] = x_extract_sleep__mutmut_4 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_5'] = x_extract_sleep__mutmut_5 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_6'] = x_extract_sleep__mutmut_6 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_7'] = x_extract_sleep__mutmut_7 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_8'] = x_extract_sleep__mutmut_8 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_9'] = x_extract_sleep__mutmut_9 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_10'] = x_extract_sleep__mutmut_10 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_11'] = x_extract_sleep__mutmut_11 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_12'] = x_extract_sleep__mutmut_12 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_13'] = x_extract_sleep__mutmut_13 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_14'] = x_extract_sleep__mutmut_14 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_15'] = x_extract_sleep__mutmut_15 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_16'] = x_extract_sleep__mutmut_16 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_17'] = x_extract_sleep__mutmut_17 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_18'] = x_extract_sleep__mutmut_18 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_19'] = x_extract_sleep__mutmut_19 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_20'] = x_extract_sleep__mutmut_20 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_21'] = x_extract_sleep__mutmut_21 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_22'] = x_extract_sleep__mutmut_22 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_23'] = x_extract_sleep__mutmut_23 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_24'] = x_extract_sleep__mutmut_24 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_25'] = x_extract_sleep__mutmut_25 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_26'] = x_extract_sleep__mutmut_26 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_27'] = x_extract_sleep__mutmut_27 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_28'] = x_extract_sleep__mutmut_28 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_29'] = x_extract_sleep__mutmut_29 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_30'] = x_extract_sleep__mutmut_30 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_31'] = x_extract_sleep__mutmut_31 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_32'] = x_extract_sleep__mutmut_32 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_33'] = x_extract_sleep__mutmut_33 # type: ignore # mutmut generated
mutants_x_extract_sleep__mutmut['x_extract_sleep__mutmut_34'] = x_extract_sleep__mutmut_34 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_extract_sleep_score__mutmut)
def extract_sleep_score(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_orig(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_1(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = None
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_2(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") and {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_3(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get(None) or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_4(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("XXsleepXX") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_5(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("SLEEP") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_6(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = None
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_7(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        None,
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_8(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        None,
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_9(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        None,
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_10(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_11(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_12(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_13(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("XXdailySleepDTOXX", "sleepScores", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_14(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailysleepdto", "sleepScores", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_15(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("DAILYSLEEPDTO", "sleepScores", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_16(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "XXsleepScoresXX", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_17(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepscores", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_18(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "SLEEPSCORES", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_19(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "XXoverallXX", "value"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_20(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "OVERALL", "value"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_21(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "XXvalueXX"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_22(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "VALUE"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_23(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        ("XXoverallSleepScoreXX",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_24(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        ("overallsleepscore",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_25(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        ("OVERALLSLEEPSCORE",),
    )
    return _build("sleep_score", score, None)


def x_extract_sleep_score__mutmut_26(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build(None, score, None)


def x_extract_sleep_score__mutmut_27(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", None, None)


def x_extract_sleep_score__mutmut_28(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build(score, None)


def x_extract_sleep_score__mutmut_29(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", None)


def x_extract_sleep_score__mutmut_30(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build("sleep_score", score, )


def x_extract_sleep_score__mutmut_31(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build("XXsleep_scoreXX", score, None)


def x_extract_sleep_score__mutmut_32(raw: dict[str, Any]) -> ExtractedMetric:
    sleep = raw.get("sleep") or {}
    score = _first(
        sleep,
        ("dailySleepDTO", "sleepScores", "overall", "value"),
        ("overallSleepScore",),
    )
    return _build("SLEEP_SCORE", score, None)

mutants_x_extract_sleep_score__mutmut['_mutmut_orig'] = x_extract_sleep_score__mutmut_orig # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_1'] = x_extract_sleep_score__mutmut_1 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_2'] = x_extract_sleep_score__mutmut_2 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_3'] = x_extract_sleep_score__mutmut_3 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_4'] = x_extract_sleep_score__mutmut_4 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_5'] = x_extract_sleep_score__mutmut_5 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_6'] = x_extract_sleep_score__mutmut_6 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_7'] = x_extract_sleep_score__mutmut_7 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_8'] = x_extract_sleep_score__mutmut_8 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_9'] = x_extract_sleep_score__mutmut_9 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_10'] = x_extract_sleep_score__mutmut_10 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_11'] = x_extract_sleep_score__mutmut_11 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_12'] = x_extract_sleep_score__mutmut_12 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_13'] = x_extract_sleep_score__mutmut_13 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_14'] = x_extract_sleep_score__mutmut_14 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_15'] = x_extract_sleep_score__mutmut_15 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_16'] = x_extract_sleep_score__mutmut_16 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_17'] = x_extract_sleep_score__mutmut_17 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_18'] = x_extract_sleep_score__mutmut_18 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_19'] = x_extract_sleep_score__mutmut_19 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_20'] = x_extract_sleep_score__mutmut_20 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_21'] = x_extract_sleep_score__mutmut_21 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_22'] = x_extract_sleep_score__mutmut_22 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_23'] = x_extract_sleep_score__mutmut_23 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_24'] = x_extract_sleep_score__mutmut_24 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_25'] = x_extract_sleep_score__mutmut_25 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_26'] = x_extract_sleep_score__mutmut_26 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_27'] = x_extract_sleep_score__mutmut_27 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_28'] = x_extract_sleep_score__mutmut_28 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_29'] = x_extract_sleep_score__mutmut_29 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_30'] = x_extract_sleep_score__mutmut_30 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_31'] = x_extract_sleep_score__mutmut_31 # type: ignore # mutmut generated
mutants_x_extract_sleep_score__mutmut['x_extract_sleep_score__mutmut_32'] = x_extract_sleep_score__mutmut_32 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_extract_hrv__mutmut)
def extract_hrv(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_orig(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_1(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = None
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_2(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") and {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_3(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get(None) or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_4(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("XXhrvXX") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_5(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("HRV") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_6(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = None
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_7(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        None,
        ("hrvSummary", "lastNightAvg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_8(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        None,
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_9(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        None,
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_10(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        ("hrvSummary", "lastNightAvg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_11(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_12(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_13(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("XXhrvSummaryXX", "lastNightAvg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_14(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvsummary", "lastNightAvg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_15(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("HRVSUMMARY", "lastNightAvg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_16(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "XXlastNightAvgXX"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_17(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastnightavg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_18(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "LASTNIGHTAVG"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_19(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("XXhrvSummaryXX", "weeklyAvg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_20(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("hrvsummary", "weeklyAvg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_21(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("HRVSUMMARY", "weeklyAvg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_22(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("hrvSummary", "XXweeklyAvgXX"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_23(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("hrvSummary", "weeklyavg"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_24(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("hrvSummary", "WEEKLYAVG"),
    )
    return _build("hrv", avg, hrv)


def x_extract_hrv__mutmut_25(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build(None, avg, hrv)


def x_extract_hrv__mutmut_26(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", None, hrv)


def x_extract_hrv__mutmut_27(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", avg, None)


def x_extract_hrv__mutmut_28(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build(avg, hrv)


def x_extract_hrv__mutmut_29(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", hrv)


def x_extract_hrv__mutmut_30(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("hrv", avg, )


def x_extract_hrv__mutmut_31(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("XXhrvXX", avg, hrv)


def x_extract_hrv__mutmut_32(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    avg = _first(
        hrv,
        ("hrvSummary", "lastNightAvg"),
        ("hrvSummary", "weeklyAvg"),
    )
    return _build("HRV", avg, hrv)

mutants_x_extract_hrv__mutmut['_mutmut_orig'] = x_extract_hrv__mutmut_orig # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_1'] = x_extract_hrv__mutmut_1 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_2'] = x_extract_hrv__mutmut_2 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_3'] = x_extract_hrv__mutmut_3 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_4'] = x_extract_hrv__mutmut_4 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_5'] = x_extract_hrv__mutmut_5 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_6'] = x_extract_hrv__mutmut_6 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_7'] = x_extract_hrv__mutmut_7 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_8'] = x_extract_hrv__mutmut_8 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_9'] = x_extract_hrv__mutmut_9 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_10'] = x_extract_hrv__mutmut_10 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_11'] = x_extract_hrv__mutmut_11 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_12'] = x_extract_hrv__mutmut_12 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_13'] = x_extract_hrv__mutmut_13 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_14'] = x_extract_hrv__mutmut_14 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_15'] = x_extract_hrv__mutmut_15 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_16'] = x_extract_hrv__mutmut_16 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_17'] = x_extract_hrv__mutmut_17 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_18'] = x_extract_hrv__mutmut_18 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_19'] = x_extract_hrv__mutmut_19 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_20'] = x_extract_hrv__mutmut_20 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_21'] = x_extract_hrv__mutmut_21 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_22'] = x_extract_hrv__mutmut_22 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_23'] = x_extract_hrv__mutmut_23 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_24'] = x_extract_hrv__mutmut_24 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_25'] = x_extract_hrv__mutmut_25 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_26'] = x_extract_hrv__mutmut_26 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_27'] = x_extract_hrv__mutmut_27 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_28'] = x_extract_hrv__mutmut_28 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_29'] = x_extract_hrv__mutmut_29 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_30'] = x_extract_hrv__mutmut_30 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_31'] = x_extract_hrv__mutmut_31 # type: ignore # mutmut generated
mutants_x_extract_hrv__mutmut['x_extract_hrv__mutmut_32'] = x_extract_hrv__mutmut_32 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_extract_hrv_weekly__mutmut)
def extract_hrv_weekly(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    weekly = _first(hrv, ("hrvSummary", "weeklyAvg"))
    return _build("hrv_weekly", weekly, None)


def x_extract_hrv_weekly__mutmut_orig(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    weekly = _first(hrv, ("hrvSummary", "weeklyAvg"))
    return _build("hrv_weekly", weekly, None)


def x_extract_hrv_weekly__mutmut_1(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = None
    weekly = _first(hrv, ("hrvSummary", "weeklyAvg"))
    return _build("hrv_weekly", weekly, None)


def x_extract_hrv_weekly__mutmut_2(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") and {}
    weekly = _first(hrv, ("hrvSummary", "weeklyAvg"))
    return _build("hrv_weekly", weekly, None)


def x_extract_hrv_weekly__mutmut_3(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get(None) or {}
    weekly = _first(hrv, ("hrvSummary", "weeklyAvg"))
    return _build("hrv_weekly", weekly, None)


def x_extract_hrv_weekly__mutmut_4(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("XXhrvXX") or {}
    weekly = _first(hrv, ("hrvSummary", "weeklyAvg"))
    return _build("hrv_weekly", weekly, None)


def x_extract_hrv_weekly__mutmut_5(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("HRV") or {}
    weekly = _first(hrv, ("hrvSummary", "weeklyAvg"))
    return _build("hrv_weekly", weekly, None)


def x_extract_hrv_weekly__mutmut_6(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    weekly = None
    return _build("hrv_weekly", weekly, None)


def x_extract_hrv_weekly__mutmut_7(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    weekly = _first(None, ("hrvSummary", "weeklyAvg"))
    return _build("hrv_weekly", weekly, None)


def x_extract_hrv_weekly__mutmut_8(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    weekly = _first(hrv, None)
    return _build("hrv_weekly", weekly, None)


def x_extract_hrv_weekly__mutmut_9(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    weekly = _first(("hrvSummary", "weeklyAvg"))
    return _build("hrv_weekly", weekly, None)


def x_extract_hrv_weekly__mutmut_10(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    weekly = _first(hrv, )
    return _build("hrv_weekly", weekly, None)


def x_extract_hrv_weekly__mutmut_11(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    weekly = _first(hrv, ("XXhrvSummaryXX", "weeklyAvg"))
    return _build("hrv_weekly", weekly, None)


def x_extract_hrv_weekly__mutmut_12(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    weekly = _first(hrv, ("hrvsummary", "weeklyAvg"))
    return _build("hrv_weekly", weekly, None)


def x_extract_hrv_weekly__mutmut_13(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    weekly = _first(hrv, ("HRVSUMMARY", "weeklyAvg"))
    return _build("hrv_weekly", weekly, None)


def x_extract_hrv_weekly__mutmut_14(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    weekly = _first(hrv, ("hrvSummary", "XXweeklyAvgXX"))
    return _build("hrv_weekly", weekly, None)


def x_extract_hrv_weekly__mutmut_15(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    weekly = _first(hrv, ("hrvSummary", "weeklyavg"))
    return _build("hrv_weekly", weekly, None)


def x_extract_hrv_weekly__mutmut_16(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    weekly = _first(hrv, ("hrvSummary", "WEEKLYAVG"))
    return _build("hrv_weekly", weekly, None)


def x_extract_hrv_weekly__mutmut_17(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    weekly = _first(hrv, ("hrvSummary", "weeklyAvg"))
    return _build(None, weekly, None)


def x_extract_hrv_weekly__mutmut_18(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    weekly = _first(hrv, ("hrvSummary", "weeklyAvg"))
    return _build("hrv_weekly", None, None)


def x_extract_hrv_weekly__mutmut_19(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    weekly = _first(hrv, ("hrvSummary", "weeklyAvg"))
    return _build(weekly, None)


def x_extract_hrv_weekly__mutmut_20(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    weekly = _first(hrv, ("hrvSummary", "weeklyAvg"))
    return _build("hrv_weekly", None)


def x_extract_hrv_weekly__mutmut_21(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    weekly = _first(hrv, ("hrvSummary", "weeklyAvg"))
    return _build("hrv_weekly", weekly, )


def x_extract_hrv_weekly__mutmut_22(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    weekly = _first(hrv, ("hrvSummary", "weeklyAvg"))
    return _build("XXhrv_weeklyXX", weekly, None)


def x_extract_hrv_weekly__mutmut_23(raw: dict[str, Any]) -> ExtractedMetric:
    hrv = raw.get("hrv") or {}
    weekly = _first(hrv, ("hrvSummary", "weeklyAvg"))
    return _build("HRV_WEEKLY", weekly, None)

mutants_x_extract_hrv_weekly__mutmut['_mutmut_orig'] = x_extract_hrv_weekly__mutmut_orig # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_1'] = x_extract_hrv_weekly__mutmut_1 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_2'] = x_extract_hrv_weekly__mutmut_2 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_3'] = x_extract_hrv_weekly__mutmut_3 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_4'] = x_extract_hrv_weekly__mutmut_4 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_5'] = x_extract_hrv_weekly__mutmut_5 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_6'] = x_extract_hrv_weekly__mutmut_6 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_7'] = x_extract_hrv_weekly__mutmut_7 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_8'] = x_extract_hrv_weekly__mutmut_8 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_9'] = x_extract_hrv_weekly__mutmut_9 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_10'] = x_extract_hrv_weekly__mutmut_10 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_11'] = x_extract_hrv_weekly__mutmut_11 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_12'] = x_extract_hrv_weekly__mutmut_12 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_13'] = x_extract_hrv_weekly__mutmut_13 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_14'] = x_extract_hrv_weekly__mutmut_14 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_15'] = x_extract_hrv_weekly__mutmut_15 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_16'] = x_extract_hrv_weekly__mutmut_16 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_17'] = x_extract_hrv_weekly__mutmut_17 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_18'] = x_extract_hrv_weekly__mutmut_18 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_19'] = x_extract_hrv_weekly__mutmut_19 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_20'] = x_extract_hrv_weekly__mutmut_20 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_21'] = x_extract_hrv_weekly__mutmut_21 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_22'] = x_extract_hrv_weekly__mutmut_22 # type: ignore # mutmut generated
mutants_x_extract_hrv_weekly__mutmut['x_extract_hrv_weekly__mutmut_23'] = x_extract_hrv_weekly__mutmut_23 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_extract_body_battery__mutmut)
def extract_body_battery(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_orig(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_1(raw: dict[str, Any]) -> ExtractedMetric:
    stats = None
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_2(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") and {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_3(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get(None) or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_4(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("XXstatsXX") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_5(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("STATS") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_6(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = None
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_7(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") and []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_8(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get(None) or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_9(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("XXbody_batteryXX") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_10(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("BODY_BATTERY") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_11(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = None
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_12(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(None, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_13(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, None)
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_14(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_15(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, )
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_16(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("XXbodyBatteryMostRecentValueXX",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_17(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodybatterymostrecentvalue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_18(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("BODYBATTERYMOSTRECENTVALUE",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_19(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None or isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_20(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is not None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_21(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(None):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_22(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_23(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if (isinstance(entry, dict)) and False else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_24(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if (isinstance(entry, dict)) or True else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_25(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get(None) if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_26(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("XXbodyBatteryValuesArrayXX") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_27(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodybatteryvaluesarray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_28(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("BODYBATTERYVALUESARRAY") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_29(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_30(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                break
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_31(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(None):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_32(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 or point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_33(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) or len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_34(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) > 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_35(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 3 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_36(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[2] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_37(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_38(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = None
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_39(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[2]
                    break
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_40(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    return
            if value is not None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_41(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is None:
                break
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_42(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                return
    return _build("body_battery", value, bb)


def x_extract_body_battery__mutmut_43(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build(None, value, bb)


def x_extract_body_battery__mutmut_44(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", None, bb)


def x_extract_body_battery__mutmut_45(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, None)


def x_extract_body_battery__mutmut_46(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build(value, bb)


def x_extract_body_battery__mutmut_47(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", bb)


def x_extract_body_battery__mutmut_48(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("body_battery", value, )


def x_extract_body_battery__mutmut_49(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("XXbody_batteryXX", value, bb)


def x_extract_body_battery__mutmut_50(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    bb = raw.get("body_battery") or []
    value = _first(stats, ("bodyBatteryMostRecentValue",))
    if value is None and isinstance(bb, list):
        for entry in reversed(bb):
            arr = entry.get("bodyBatteryValuesArray") if isinstance(entry, dict) else None
            if not arr:
                continue
            for point in reversed(arr):
                if isinstance(point, list) and len(point) >= 2 and point[1] is not None:
                    value = point[1]
                    break
            if value is not None:
                break
    return _build("BODY_BATTERY", value, bb)

mutants_x_extract_body_battery__mutmut['_mutmut_orig'] = x_extract_body_battery__mutmut_orig # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_1'] = x_extract_body_battery__mutmut_1 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_2'] = x_extract_body_battery__mutmut_2 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_3'] = x_extract_body_battery__mutmut_3 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_4'] = x_extract_body_battery__mutmut_4 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_5'] = x_extract_body_battery__mutmut_5 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_6'] = x_extract_body_battery__mutmut_6 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_7'] = x_extract_body_battery__mutmut_7 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_8'] = x_extract_body_battery__mutmut_8 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_9'] = x_extract_body_battery__mutmut_9 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_10'] = x_extract_body_battery__mutmut_10 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_11'] = x_extract_body_battery__mutmut_11 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_12'] = x_extract_body_battery__mutmut_12 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_13'] = x_extract_body_battery__mutmut_13 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_14'] = x_extract_body_battery__mutmut_14 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_15'] = x_extract_body_battery__mutmut_15 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_16'] = x_extract_body_battery__mutmut_16 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_17'] = x_extract_body_battery__mutmut_17 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_18'] = x_extract_body_battery__mutmut_18 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_19'] = x_extract_body_battery__mutmut_19 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_20'] = x_extract_body_battery__mutmut_20 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_21'] = x_extract_body_battery__mutmut_21 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_22'] = x_extract_body_battery__mutmut_22 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_23'] = x_extract_body_battery__mutmut_23 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_24'] = x_extract_body_battery__mutmut_24 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_25'] = x_extract_body_battery__mutmut_25 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_26'] = x_extract_body_battery__mutmut_26 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_27'] = x_extract_body_battery__mutmut_27 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_28'] = x_extract_body_battery__mutmut_28 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_29'] = x_extract_body_battery__mutmut_29 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_30'] = x_extract_body_battery__mutmut_30 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_31'] = x_extract_body_battery__mutmut_31 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_32'] = x_extract_body_battery__mutmut_32 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_33'] = x_extract_body_battery__mutmut_33 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_34'] = x_extract_body_battery__mutmut_34 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_35'] = x_extract_body_battery__mutmut_35 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_36'] = x_extract_body_battery__mutmut_36 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_37'] = x_extract_body_battery__mutmut_37 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_38'] = x_extract_body_battery__mutmut_38 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_39'] = x_extract_body_battery__mutmut_39 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_40'] = x_extract_body_battery__mutmut_40 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_41'] = x_extract_body_battery__mutmut_41 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_42'] = x_extract_body_battery__mutmut_42 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_43'] = x_extract_body_battery__mutmut_43 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_44'] = x_extract_body_battery__mutmut_44 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_45'] = x_extract_body_battery__mutmut_45 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_46'] = x_extract_body_battery__mutmut_46 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_47'] = x_extract_body_battery__mutmut_47 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_48'] = x_extract_body_battery__mutmut_48 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_49'] = x_extract_body_battery__mutmut_49 # type: ignore # mutmut generated
mutants_x_extract_body_battery__mutmut['x_extract_body_battery__mutmut_50'] = x_extract_body_battery__mutmut_50 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_extract_stress_daily__mutmut)
def extract_stress_daily(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("stress") or {}
    value = _first(stress, ("avgStressLevel",))
    return _build("stress_daily", value, stress)


def x_extract_stress_daily__mutmut_orig(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("stress") or {}
    value = _first(stress, ("avgStressLevel",))
    return _build("stress_daily", value, stress)


def x_extract_stress_daily__mutmut_1(raw: dict[str, Any]) -> ExtractedMetric:
    stress = None
    value = _first(stress, ("avgStressLevel",))
    return _build("stress_daily", value, stress)


def x_extract_stress_daily__mutmut_2(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("stress") and {}
    value = _first(stress, ("avgStressLevel",))
    return _build("stress_daily", value, stress)


def x_extract_stress_daily__mutmut_3(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get(None) or {}
    value = _first(stress, ("avgStressLevel",))
    return _build("stress_daily", value, stress)


def x_extract_stress_daily__mutmut_4(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("XXstressXX") or {}
    value = _first(stress, ("avgStressLevel",))
    return _build("stress_daily", value, stress)


def x_extract_stress_daily__mutmut_5(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("STRESS") or {}
    value = _first(stress, ("avgStressLevel",))
    return _build("stress_daily", value, stress)


def x_extract_stress_daily__mutmut_6(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("stress") or {}
    value = None
    return _build("stress_daily", value, stress)


def x_extract_stress_daily__mutmut_7(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("stress") or {}
    value = _first(None, ("avgStressLevel",))
    return _build("stress_daily", value, stress)


def x_extract_stress_daily__mutmut_8(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("stress") or {}
    value = _first(stress, None)
    return _build("stress_daily", value, stress)


def x_extract_stress_daily__mutmut_9(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("stress") or {}
    value = _first(("avgStressLevel",))
    return _build("stress_daily", value, stress)


def x_extract_stress_daily__mutmut_10(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("stress") or {}
    value = _first(stress, )
    return _build("stress_daily", value, stress)


def x_extract_stress_daily__mutmut_11(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("stress") or {}
    value = _first(stress, ("XXavgStressLevelXX",))
    return _build("stress_daily", value, stress)


def x_extract_stress_daily__mutmut_12(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("stress") or {}
    value = _first(stress, ("avgstresslevel",))
    return _build("stress_daily", value, stress)


def x_extract_stress_daily__mutmut_13(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("stress") or {}
    value = _first(stress, ("AVGSTRESSLEVEL",))
    return _build("stress_daily", value, stress)


def x_extract_stress_daily__mutmut_14(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("stress") or {}
    value = _first(stress, ("avgStressLevel",))
    return _build(None, value, stress)


def x_extract_stress_daily__mutmut_15(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("stress") or {}
    value = _first(stress, ("avgStressLevel",))
    return _build("stress_daily", None, stress)


def x_extract_stress_daily__mutmut_16(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("stress") or {}
    value = _first(stress, ("avgStressLevel",))
    return _build("stress_daily", value, None)


def x_extract_stress_daily__mutmut_17(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("stress") or {}
    value = _first(stress, ("avgStressLevel",))
    return _build(value, stress)


def x_extract_stress_daily__mutmut_18(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("stress") or {}
    value = _first(stress, ("avgStressLevel",))
    return _build("stress_daily", stress)


def x_extract_stress_daily__mutmut_19(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("stress") or {}
    value = _first(stress, ("avgStressLevel",))
    return _build("stress_daily", value, )


def x_extract_stress_daily__mutmut_20(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("stress") or {}
    value = _first(stress, ("avgStressLevel",))
    return _build("XXstress_dailyXX", value, stress)


def x_extract_stress_daily__mutmut_21(raw: dict[str, Any]) -> ExtractedMetric:
    stress = raw.get("stress") or {}
    value = _first(stress, ("avgStressLevel",))
    return _build("STRESS_DAILY", value, stress)

mutants_x_extract_stress_daily__mutmut['_mutmut_orig'] = x_extract_stress_daily__mutmut_orig # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_1'] = x_extract_stress_daily__mutmut_1 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_2'] = x_extract_stress_daily__mutmut_2 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_3'] = x_extract_stress_daily__mutmut_3 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_4'] = x_extract_stress_daily__mutmut_4 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_5'] = x_extract_stress_daily__mutmut_5 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_6'] = x_extract_stress_daily__mutmut_6 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_7'] = x_extract_stress_daily__mutmut_7 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_8'] = x_extract_stress_daily__mutmut_8 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_9'] = x_extract_stress_daily__mutmut_9 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_10'] = x_extract_stress_daily__mutmut_10 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_11'] = x_extract_stress_daily__mutmut_11 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_12'] = x_extract_stress_daily__mutmut_12 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_13'] = x_extract_stress_daily__mutmut_13 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_14'] = x_extract_stress_daily__mutmut_14 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_15'] = x_extract_stress_daily__mutmut_15 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_16'] = x_extract_stress_daily__mutmut_16 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_17'] = x_extract_stress_daily__mutmut_17 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_18'] = x_extract_stress_daily__mutmut_18 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_19'] = x_extract_stress_daily__mutmut_19 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_20'] = x_extract_stress_daily__mutmut_20 # type: ignore # mutmut generated
mutants_x_extract_stress_daily__mutmut['x_extract_stress_daily__mutmut_21'] = x_extract_stress_daily__mutmut_21 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_extract_resting_hr__mutmut)
def extract_resting_hr(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("restingHeartRate",))
    return _build("resting_hr", value, raw.get("rhr"))


def x_extract_resting_hr__mutmut_orig(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("restingHeartRate",))
    return _build("resting_hr", value, raw.get("rhr"))


def x_extract_resting_hr__mutmut_1(raw: dict[str, Any]) -> ExtractedMetric:
    stats = None
    value = _first(stats, ("restingHeartRate",))
    return _build("resting_hr", value, raw.get("rhr"))


def x_extract_resting_hr__mutmut_2(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") and {}
    value = _first(stats, ("restingHeartRate",))
    return _build("resting_hr", value, raw.get("rhr"))


def x_extract_resting_hr__mutmut_3(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get(None) or {}
    value = _first(stats, ("restingHeartRate",))
    return _build("resting_hr", value, raw.get("rhr"))


def x_extract_resting_hr__mutmut_4(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("XXstatsXX") or {}
    value = _first(stats, ("restingHeartRate",))
    return _build("resting_hr", value, raw.get("rhr"))


def x_extract_resting_hr__mutmut_5(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("STATS") or {}
    value = _first(stats, ("restingHeartRate",))
    return _build("resting_hr", value, raw.get("rhr"))


def x_extract_resting_hr__mutmut_6(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = None
    return _build("resting_hr", value, raw.get("rhr"))


def x_extract_resting_hr__mutmut_7(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(None, ("restingHeartRate",))
    return _build("resting_hr", value, raw.get("rhr"))


def x_extract_resting_hr__mutmut_8(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, None)
    return _build("resting_hr", value, raw.get("rhr"))


def x_extract_resting_hr__mutmut_9(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(("restingHeartRate",))
    return _build("resting_hr", value, raw.get("rhr"))


def x_extract_resting_hr__mutmut_10(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, )
    return _build("resting_hr", value, raw.get("rhr"))


def x_extract_resting_hr__mutmut_11(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("XXrestingHeartRateXX",))
    return _build("resting_hr", value, raw.get("rhr"))


def x_extract_resting_hr__mutmut_12(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("restingheartrate",))
    return _build("resting_hr", value, raw.get("rhr"))


def x_extract_resting_hr__mutmut_13(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("RESTINGHEARTRATE",))
    return _build("resting_hr", value, raw.get("rhr"))


def x_extract_resting_hr__mutmut_14(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("restingHeartRate",))
    return _build(None, value, raw.get("rhr"))


def x_extract_resting_hr__mutmut_15(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("restingHeartRate",))
    return _build("resting_hr", None, raw.get("rhr"))


def x_extract_resting_hr__mutmut_16(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("restingHeartRate",))
    return _build("resting_hr", value, None)


def x_extract_resting_hr__mutmut_17(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("restingHeartRate",))
    return _build(value, raw.get("rhr"))


def x_extract_resting_hr__mutmut_18(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("restingHeartRate",))
    return _build("resting_hr", raw.get("rhr"))


def x_extract_resting_hr__mutmut_19(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("restingHeartRate",))
    return _build("resting_hr", value, )


def x_extract_resting_hr__mutmut_20(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("restingHeartRate",))
    return _build("XXresting_hrXX", value, raw.get("rhr"))


def x_extract_resting_hr__mutmut_21(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("restingHeartRate",))
    return _build("RESTING_HR", value, raw.get("rhr"))


def x_extract_resting_hr__mutmut_22(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("restingHeartRate",))
    return _build("resting_hr", value, raw.get(None))


def x_extract_resting_hr__mutmut_23(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("restingHeartRate",))
    return _build("resting_hr", value, raw.get("XXrhrXX"))


def x_extract_resting_hr__mutmut_24(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("restingHeartRate",))
    return _build("resting_hr", value, raw.get("RHR"))

mutants_x_extract_resting_hr__mutmut['_mutmut_orig'] = x_extract_resting_hr__mutmut_orig # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_1'] = x_extract_resting_hr__mutmut_1 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_2'] = x_extract_resting_hr__mutmut_2 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_3'] = x_extract_resting_hr__mutmut_3 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_4'] = x_extract_resting_hr__mutmut_4 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_5'] = x_extract_resting_hr__mutmut_5 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_6'] = x_extract_resting_hr__mutmut_6 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_7'] = x_extract_resting_hr__mutmut_7 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_8'] = x_extract_resting_hr__mutmut_8 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_9'] = x_extract_resting_hr__mutmut_9 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_10'] = x_extract_resting_hr__mutmut_10 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_11'] = x_extract_resting_hr__mutmut_11 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_12'] = x_extract_resting_hr__mutmut_12 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_13'] = x_extract_resting_hr__mutmut_13 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_14'] = x_extract_resting_hr__mutmut_14 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_15'] = x_extract_resting_hr__mutmut_15 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_16'] = x_extract_resting_hr__mutmut_16 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_17'] = x_extract_resting_hr__mutmut_17 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_18'] = x_extract_resting_hr__mutmut_18 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_19'] = x_extract_resting_hr__mutmut_19 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_20'] = x_extract_resting_hr__mutmut_20 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_21'] = x_extract_resting_hr__mutmut_21 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_22'] = x_extract_resting_hr__mutmut_22 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_23'] = x_extract_resting_hr__mutmut_23 # type: ignore # mutmut generated
mutants_x_extract_resting_hr__mutmut['x_extract_resting_hr__mutmut_24'] = x_extract_resting_hr__mutmut_24 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_extract_steps__mutmut)
def extract_steps(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("totalSteps",))
    return _build("steps", value, raw.get("steps"))


def x_extract_steps__mutmut_orig(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("totalSteps",))
    return _build("steps", value, raw.get("steps"))


def x_extract_steps__mutmut_1(raw: dict[str, Any]) -> ExtractedMetric:
    stats = None
    value = _first(stats, ("totalSteps",))
    return _build("steps", value, raw.get("steps"))


def x_extract_steps__mutmut_2(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") and {}
    value = _first(stats, ("totalSteps",))
    return _build("steps", value, raw.get("steps"))


def x_extract_steps__mutmut_3(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get(None) or {}
    value = _first(stats, ("totalSteps",))
    return _build("steps", value, raw.get("steps"))


def x_extract_steps__mutmut_4(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("XXstatsXX") or {}
    value = _first(stats, ("totalSteps",))
    return _build("steps", value, raw.get("steps"))


def x_extract_steps__mutmut_5(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("STATS") or {}
    value = _first(stats, ("totalSteps",))
    return _build("steps", value, raw.get("steps"))


def x_extract_steps__mutmut_6(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = None
    return _build("steps", value, raw.get("steps"))


def x_extract_steps__mutmut_7(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(None, ("totalSteps",))
    return _build("steps", value, raw.get("steps"))


def x_extract_steps__mutmut_8(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, None)
    return _build("steps", value, raw.get("steps"))


def x_extract_steps__mutmut_9(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(("totalSteps",))
    return _build("steps", value, raw.get("steps"))


def x_extract_steps__mutmut_10(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, )
    return _build("steps", value, raw.get("steps"))


def x_extract_steps__mutmut_11(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("XXtotalStepsXX",))
    return _build("steps", value, raw.get("steps"))


def x_extract_steps__mutmut_12(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("totalsteps",))
    return _build("steps", value, raw.get("steps"))


def x_extract_steps__mutmut_13(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("TOTALSTEPS",))
    return _build("steps", value, raw.get("steps"))


def x_extract_steps__mutmut_14(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("totalSteps",))
    return _build(None, value, raw.get("steps"))


def x_extract_steps__mutmut_15(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("totalSteps",))
    return _build("steps", None, raw.get("steps"))


def x_extract_steps__mutmut_16(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("totalSteps",))
    return _build("steps", value, None)


def x_extract_steps__mutmut_17(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("totalSteps",))
    return _build(value, raw.get("steps"))


def x_extract_steps__mutmut_18(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("totalSteps",))
    return _build("steps", raw.get("steps"))


def x_extract_steps__mutmut_19(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("totalSteps",))
    return _build("steps", value, )


def x_extract_steps__mutmut_20(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("totalSteps",))
    return _build("XXstepsXX", value, raw.get("steps"))


def x_extract_steps__mutmut_21(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("totalSteps",))
    return _build("STEPS", value, raw.get("steps"))


def x_extract_steps__mutmut_22(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("totalSteps",))
    return _build("steps", value, raw.get(None))


def x_extract_steps__mutmut_23(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("totalSteps",))
    return _build("steps", value, raw.get("XXstepsXX"))


def x_extract_steps__mutmut_24(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(stats, ("totalSteps",))
    return _build("steps", value, raw.get("STEPS"))

mutants_x_extract_steps__mutmut['_mutmut_orig'] = x_extract_steps__mutmut_orig # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_1'] = x_extract_steps__mutmut_1 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_2'] = x_extract_steps__mutmut_2 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_3'] = x_extract_steps__mutmut_3 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_4'] = x_extract_steps__mutmut_4 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_5'] = x_extract_steps__mutmut_5 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_6'] = x_extract_steps__mutmut_6 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_7'] = x_extract_steps__mutmut_7 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_8'] = x_extract_steps__mutmut_8 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_9'] = x_extract_steps__mutmut_9 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_10'] = x_extract_steps__mutmut_10 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_11'] = x_extract_steps__mutmut_11 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_12'] = x_extract_steps__mutmut_12 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_13'] = x_extract_steps__mutmut_13 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_14'] = x_extract_steps__mutmut_14 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_15'] = x_extract_steps__mutmut_15 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_16'] = x_extract_steps__mutmut_16 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_17'] = x_extract_steps__mutmut_17 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_18'] = x_extract_steps__mutmut_18 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_19'] = x_extract_steps__mutmut_19 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_20'] = x_extract_steps__mutmut_20 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_21'] = x_extract_steps__mutmut_21 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_22'] = x_extract_steps__mutmut_22 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_23'] = x_extract_steps__mutmut_23 # type: ignore # mutmut generated
mutants_x_extract_steps__mutmut['x_extract_steps__mutmut_24'] = x_extract_steps__mutmut_24 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_extract_calories__mutmut)
def extract_calories(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_orig(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_1(raw: dict[str, Any]) -> ExtractedMetric:
    stats = None
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_2(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") and {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_3(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get(None) or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_4(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("XXstatsXX") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_5(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("STATS") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_6(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = None
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_7(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        None,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_8(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        None,
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_9(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_10(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_11(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("XXtotalKilocaloriesXX",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_12(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalkilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_13(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("TOTALKILOCALORIES",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_14(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is not None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_15(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = None
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_16(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") and {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_17(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get(None) or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_18(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("XXuser_summaryXX") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_19(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("USER_SUMMARY") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_20(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = None
    return _build("calories", value, stats)


def x_extract_calories__mutmut_21(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(None, ("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_22(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, None)
    return _build("calories", value, stats)


def x_extract_calories__mutmut_23(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(("totalKilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_24(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, )
    return _build("calories", value, stats)


def x_extract_calories__mutmut_25(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("XXtotalKilocaloriesXX",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_26(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalkilocalories",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_27(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("TOTALKILOCALORIES",))
    return _build("calories", value, stats)


def x_extract_calories__mutmut_28(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build(None, value, stats)


def x_extract_calories__mutmut_29(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", None, stats)


def x_extract_calories__mutmut_30(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, None)


def x_extract_calories__mutmut_31(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build(value, stats)


def x_extract_calories__mutmut_32(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", stats)


def x_extract_calories__mutmut_33(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("calories", value, )


def x_extract_calories__mutmut_34(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("XXcaloriesXX", value, stats)


def x_extract_calories__mutmut_35(raw: dict[str, Any]) -> ExtractedMetric:
    stats = raw.get("stats") or {}
    value = _first(
        stats,
        ("totalKilocalories",),
    )
    if value is None:
        user_summary = raw.get("user_summary") or {}
        value = _first(user_summary, ("totalKilocalories",))
    return _build("CALORIES", value, stats)

mutants_x_extract_calories__mutmut['_mutmut_orig'] = x_extract_calories__mutmut_orig # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_1'] = x_extract_calories__mutmut_1 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_2'] = x_extract_calories__mutmut_2 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_3'] = x_extract_calories__mutmut_3 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_4'] = x_extract_calories__mutmut_4 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_5'] = x_extract_calories__mutmut_5 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_6'] = x_extract_calories__mutmut_6 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_7'] = x_extract_calories__mutmut_7 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_8'] = x_extract_calories__mutmut_8 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_9'] = x_extract_calories__mutmut_9 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_10'] = x_extract_calories__mutmut_10 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_11'] = x_extract_calories__mutmut_11 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_12'] = x_extract_calories__mutmut_12 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_13'] = x_extract_calories__mutmut_13 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_14'] = x_extract_calories__mutmut_14 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_15'] = x_extract_calories__mutmut_15 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_16'] = x_extract_calories__mutmut_16 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_17'] = x_extract_calories__mutmut_17 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_18'] = x_extract_calories__mutmut_18 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_19'] = x_extract_calories__mutmut_19 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_20'] = x_extract_calories__mutmut_20 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_21'] = x_extract_calories__mutmut_21 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_22'] = x_extract_calories__mutmut_22 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_23'] = x_extract_calories__mutmut_23 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_24'] = x_extract_calories__mutmut_24 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_25'] = x_extract_calories__mutmut_25 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_26'] = x_extract_calories__mutmut_26 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_27'] = x_extract_calories__mutmut_27 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_28'] = x_extract_calories__mutmut_28 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_29'] = x_extract_calories__mutmut_29 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_30'] = x_extract_calories__mutmut_30 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_31'] = x_extract_calories__mutmut_31 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_32'] = x_extract_calories__mutmut_32 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_33'] = x_extract_calories__mutmut_33 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_34'] = x_extract_calories__mutmut_34 # type: ignore # mutmut generated
mutants_x_extract_calories__mutmut['x_extract_calories__mutmut_35'] = x_extract_calories__mutmut_35 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_extract_training_readiness__mutmut)
def extract_training_readiness(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = readiness.get("score") if isinstance(readiness, dict) else None
    return _build("training_readiness", value, readiness)


def x_extract_training_readiness__mutmut_orig(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = readiness.get("score") if isinstance(readiness, dict) else None
    return _build("training_readiness", value, readiness)


def x_extract_training_readiness__mutmut_1(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = None
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = readiness.get("score") if isinstance(readiness, dict) else None
    return _build("training_readiness", value, readiness)


def x_extract_training_readiness__mutmut_2(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") and {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = readiness.get("score") if isinstance(readiness, dict) else None
    return _build("training_readiness", value, readiness)


def x_extract_training_readiness__mutmut_3(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get(None) or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = readiness.get("score") if isinstance(readiness, dict) else None
    return _build("training_readiness", value, readiness)


def x_extract_training_readiness__mutmut_4(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("XXtraining_readinessXX") or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = readiness.get("score") if isinstance(readiness, dict) else None
    return _build("training_readiness", value, readiness)


def x_extract_training_readiness__mutmut_5(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("TRAINING_READINESS") or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = readiness.get("score") if isinstance(readiness, dict) else None
    return _build("training_readiness", value, readiness)


def x_extract_training_readiness__mutmut_6(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") or {}
    if isinstance(readiness, list) or readiness:
        readiness = readiness[-1]
    value = readiness.get("score") if isinstance(readiness, dict) else None
    return _build("training_readiness", value, readiness)


def x_extract_training_readiness__mutmut_7(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") or {}
    if isinstance(readiness, list) and readiness:
        readiness = None
    value = readiness.get("score") if isinstance(readiness, dict) else None
    return _build("training_readiness", value, readiness)


def x_extract_training_readiness__mutmut_8(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[+1]
    value = readiness.get("score") if isinstance(readiness, dict) else None
    return _build("training_readiness", value, readiness)


def x_extract_training_readiness__mutmut_9(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-2]
    value = readiness.get("score") if isinstance(readiness, dict) else None
    return _build("training_readiness", value, readiness)


def x_extract_training_readiness__mutmut_10(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = None
    return _build("training_readiness", value, readiness)


def x_extract_training_readiness__mutmut_11(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = readiness.get("score") if (isinstance(readiness, dict)) and False else None
    return _build("training_readiness", value, readiness)


def x_extract_training_readiness__mutmut_12(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = readiness.get("score") if (isinstance(readiness, dict)) or True else None
    return _build("training_readiness", value, readiness)


def x_extract_training_readiness__mutmut_13(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = readiness.get(None) if isinstance(readiness, dict) else None
    return _build("training_readiness", value, readiness)


def x_extract_training_readiness__mutmut_14(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = readiness.get("XXscoreXX") if isinstance(readiness, dict) else None
    return _build("training_readiness", value, readiness)


def x_extract_training_readiness__mutmut_15(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = readiness.get("SCORE") if isinstance(readiness, dict) else None
    return _build("training_readiness", value, readiness)


def x_extract_training_readiness__mutmut_16(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = readiness.get("score") if isinstance(readiness, dict) else None
    return _build(None, value, readiness)


def x_extract_training_readiness__mutmut_17(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = readiness.get("score") if isinstance(readiness, dict) else None
    return _build("training_readiness", None, readiness)


def x_extract_training_readiness__mutmut_18(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = readiness.get("score") if isinstance(readiness, dict) else None
    return _build("training_readiness", value, None)


def x_extract_training_readiness__mutmut_19(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = readiness.get("score") if isinstance(readiness, dict) else None
    return _build(value, readiness)


def x_extract_training_readiness__mutmut_20(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = readiness.get("score") if isinstance(readiness, dict) else None
    return _build("training_readiness", readiness)


def x_extract_training_readiness__mutmut_21(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = readiness.get("score") if isinstance(readiness, dict) else None
    return _build("training_readiness", value, )


def x_extract_training_readiness__mutmut_22(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = readiness.get("score") if isinstance(readiness, dict) else None
    return _build("XXtraining_readinessXX", value, readiness)


def x_extract_training_readiness__mutmut_23(raw: dict[str, Any]) -> ExtractedMetric:
    readiness = raw.get("training_readiness") or {}
    if isinstance(readiness, list) and readiness:
        readiness = readiness[-1]
    value = readiness.get("score") if isinstance(readiness, dict) else None
    return _build("TRAINING_READINESS", value, readiness)

mutants_x_extract_training_readiness__mutmut['_mutmut_orig'] = x_extract_training_readiness__mutmut_orig # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_1'] = x_extract_training_readiness__mutmut_1 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_2'] = x_extract_training_readiness__mutmut_2 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_3'] = x_extract_training_readiness__mutmut_3 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_4'] = x_extract_training_readiness__mutmut_4 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_5'] = x_extract_training_readiness__mutmut_5 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_6'] = x_extract_training_readiness__mutmut_6 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_7'] = x_extract_training_readiness__mutmut_7 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_8'] = x_extract_training_readiness__mutmut_8 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_9'] = x_extract_training_readiness__mutmut_9 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_10'] = x_extract_training_readiness__mutmut_10 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_11'] = x_extract_training_readiness__mutmut_11 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_12'] = x_extract_training_readiness__mutmut_12 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_13'] = x_extract_training_readiness__mutmut_13 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_14'] = x_extract_training_readiness__mutmut_14 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_15'] = x_extract_training_readiness__mutmut_15 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_16'] = x_extract_training_readiness__mutmut_16 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_17'] = x_extract_training_readiness__mutmut_17 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_18'] = x_extract_training_readiness__mutmut_18 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_19'] = x_extract_training_readiness__mutmut_19 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_20'] = x_extract_training_readiness__mutmut_20 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_21'] = x_extract_training_readiness__mutmut_21 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_22'] = x_extract_training_readiness__mutmut_22 # type: ignore # mutmut generated
mutants_x_extract_training_readiness__mutmut['x_extract_training_readiness__mutmut_23'] = x_extract_training_readiness__mutmut_23 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_extract_vo2max__mutmut)
def extract_vo2max(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_orig(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_1(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = None
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_2(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get(None)
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_3(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("XXmax_metricsXX")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_4(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("MAX_METRICS")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_5(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = None
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_6(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if (isinstance(max_metrics, list)) and False else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_7(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if (isinstance(max_metrics, list)) or True else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_8(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = ""
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_9(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if (entries) and False else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_10(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if (entries) or True else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_11(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] - entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_12(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:2] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_13(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[+1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_14(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-2:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_15(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = None
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_16(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(None, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_17(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, None, "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_18(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", None)
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_19(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig("generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_20(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_21(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", )
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_22(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "XXgenericXX", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_23(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "GENERIC", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_24(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "XXvo2MaxValueXX")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_25(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2maxvalue")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_26(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "VO2MAXVALUE")
        if value is not None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_27(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is None:
            break
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_28(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            return
    return _build("vo2max", value, max_metrics)


def x_extract_vo2max__mutmut_29(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build(None, value, max_metrics)


def x_extract_vo2max__mutmut_30(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", None, max_metrics)


def x_extract_vo2max__mutmut_31(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, None)


def x_extract_vo2max__mutmut_32(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build(value, max_metrics)


def x_extract_vo2max__mutmut_33(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", max_metrics)


def x_extract_vo2max__mutmut_34(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("vo2max", value, )


def x_extract_vo2max__mutmut_35(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("XXvo2maxXX", value, max_metrics)


def x_extract_vo2max__mutmut_36(raw: dict[str, Any]) -> ExtractedMetric:
    max_metrics = raw.get("max_metrics")
    entries = max_metrics if isinstance(max_metrics, list) else []
    value = None
    for entry in (entries[:1] + entries[-1:]) if entries else []:
        value = _dig(entry, "generic", "vo2MaxValue")
        if value is not None:
            break
    return _build("VO2MAX", value, max_metrics)

mutants_x_extract_vo2max__mutmut['_mutmut_orig'] = x_extract_vo2max__mutmut_orig # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_1'] = x_extract_vo2max__mutmut_1 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_2'] = x_extract_vo2max__mutmut_2 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_3'] = x_extract_vo2max__mutmut_3 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_4'] = x_extract_vo2max__mutmut_4 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_5'] = x_extract_vo2max__mutmut_5 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_6'] = x_extract_vo2max__mutmut_6 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_7'] = x_extract_vo2max__mutmut_7 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_8'] = x_extract_vo2max__mutmut_8 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_9'] = x_extract_vo2max__mutmut_9 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_10'] = x_extract_vo2max__mutmut_10 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_11'] = x_extract_vo2max__mutmut_11 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_12'] = x_extract_vo2max__mutmut_12 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_13'] = x_extract_vo2max__mutmut_13 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_14'] = x_extract_vo2max__mutmut_14 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_15'] = x_extract_vo2max__mutmut_15 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_16'] = x_extract_vo2max__mutmut_16 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_17'] = x_extract_vo2max__mutmut_17 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_18'] = x_extract_vo2max__mutmut_18 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_19'] = x_extract_vo2max__mutmut_19 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_20'] = x_extract_vo2max__mutmut_20 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_21'] = x_extract_vo2max__mutmut_21 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_22'] = x_extract_vo2max__mutmut_22 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_23'] = x_extract_vo2max__mutmut_23 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_24'] = x_extract_vo2max__mutmut_24 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_25'] = x_extract_vo2max__mutmut_25 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_26'] = x_extract_vo2max__mutmut_26 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_27'] = x_extract_vo2max__mutmut_27 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_28'] = x_extract_vo2max__mutmut_28 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_29'] = x_extract_vo2max__mutmut_29 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_30'] = x_extract_vo2max__mutmut_30 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_31'] = x_extract_vo2max__mutmut_31 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_32'] = x_extract_vo2max__mutmut_32 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_33'] = x_extract_vo2max__mutmut_33 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_34'] = x_extract_vo2max__mutmut_34 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_35'] = x_extract_vo2max__mutmut_35 # type: ignore # mutmut generated
mutants_x_extract_vo2max__mutmut['x_extract_vo2max__mutmut_36'] = x_extract_vo2max__mutmut_36 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut: MutantDict = {}  # type: ignore


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
@_mutmut_mutated(mutants_x_extract_training_status__mutmut)
def extract_training_status(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_orig(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_1(raw: dict[str, Any]) -> ExtractedMetric:
    payload = None
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_2(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get(None)
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_3(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("XXtraining_statusXX")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_4(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("TRAINING_STATUS")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_5(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = None
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_6(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = "missing" if (payload is None) and False else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_7(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = "missing" if (payload is None) or True else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_8(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = "XXmissingXX" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_9(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = "MISSING" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_10(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = "missing" if payload is not None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_11(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = "missing" if payload is None else "XXokXX"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_12(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = "missing" if payload is None else "OK"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_13(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, None, status, None if payload else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_14(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, None, None if payload else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_15(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None)


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_16(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(payload, status, None if payload else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_17(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, status, None if payload else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_18(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, None if payload else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_19(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, )


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_20(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if (payload) and False else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_21(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if (payload) or True else "no data returned")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_22(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "XXno data returnedXX")


# Metrics with no scalar value (payload-only, or not yet plausibility-checked)
def x_extract_training_status__mutmut_23(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("training_status")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "NO DATA RETURNED")

mutants_x_extract_training_status__mutmut['_mutmut_orig'] = x_extract_training_status__mutmut_orig # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_1'] = x_extract_training_status__mutmut_1 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_2'] = x_extract_training_status__mutmut_2 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_3'] = x_extract_training_status__mutmut_3 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_4'] = x_extract_training_status__mutmut_4 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_5'] = x_extract_training_status__mutmut_5 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_6'] = x_extract_training_status__mutmut_6 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_7'] = x_extract_training_status__mutmut_7 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_8'] = x_extract_training_status__mutmut_8 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_9'] = x_extract_training_status__mutmut_9 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_10'] = x_extract_training_status__mutmut_10 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_11'] = x_extract_training_status__mutmut_11 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_12'] = x_extract_training_status__mutmut_12 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_13'] = x_extract_training_status__mutmut_13 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_14'] = x_extract_training_status__mutmut_14 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_15'] = x_extract_training_status__mutmut_15 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_16'] = x_extract_training_status__mutmut_16 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_17'] = x_extract_training_status__mutmut_17 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_18'] = x_extract_training_status__mutmut_18 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_19'] = x_extract_training_status__mutmut_19 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_20'] = x_extract_training_status__mutmut_20 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_21'] = x_extract_training_status__mutmut_21 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_22'] = x_extract_training_status__mutmut_22 # type: ignore # mutmut generated
mutants_x_extract_training_status__mutmut['x_extract_training_status__mutmut_23'] = x_extract_training_status__mutmut_23 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_extract_intensity_minutes__mutmut)
def extract_intensity_minutes(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


def x_extract_intensity_minutes__mutmut_orig(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


def x_extract_intensity_minutes__mutmut_1(raw: dict[str, Any]) -> ExtractedMetric:
    payload = None
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


def x_extract_intensity_minutes__mutmut_2(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get(None)
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


def x_extract_intensity_minutes__mutmut_3(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("XXintensity_minutesXX")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


def x_extract_intensity_minutes__mutmut_4(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("INTENSITY_MINUTES")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


def x_extract_intensity_minutes__mutmut_5(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = None
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


def x_extract_intensity_minutes__mutmut_6(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = "missing" if (payload is None) and False else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


def x_extract_intensity_minutes__mutmut_7(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = "missing" if (payload is None) or True else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


def x_extract_intensity_minutes__mutmut_8(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = "XXmissingXX" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


def x_extract_intensity_minutes__mutmut_9(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = "MISSING" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


def x_extract_intensity_minutes__mutmut_10(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = "missing" if payload is not None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


def x_extract_intensity_minutes__mutmut_11(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = "missing" if payload is None else "XXokXX"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


def x_extract_intensity_minutes__mutmut_12(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = "missing" if payload is None else "OK"
    return ExtractedMetric(None, payload, status, None if payload else "no data returned")


def x_extract_intensity_minutes__mutmut_13(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, None, status, None if payload else "no data returned")


def x_extract_intensity_minutes__mutmut_14(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, None, None if payload else "no data returned")


def x_extract_intensity_minutes__mutmut_15(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None)


def x_extract_intensity_minutes__mutmut_16(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(payload, status, None if payload else "no data returned")


def x_extract_intensity_minutes__mutmut_17(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, status, None if payload else "no data returned")


def x_extract_intensity_minutes__mutmut_18(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, None if payload else "no data returned")


def x_extract_intensity_minutes__mutmut_19(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, )


def x_extract_intensity_minutes__mutmut_20(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if (payload) and False else "no data returned")


def x_extract_intensity_minutes__mutmut_21(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if (payload) or True else "no data returned")


def x_extract_intensity_minutes__mutmut_22(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "XXno data returnedXX")


def x_extract_intensity_minutes__mutmut_23(raw: dict[str, Any]) -> ExtractedMetric:
    payload = raw.get("intensity_minutes")
    status = "missing" if payload is None else "ok"
    return ExtractedMetric(None, payload, status, None if payload else "NO DATA RETURNED")

mutants_x_extract_intensity_minutes__mutmut['_mutmut_orig'] = x_extract_intensity_minutes__mutmut_orig # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_1'] = x_extract_intensity_minutes__mutmut_1 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_2'] = x_extract_intensity_minutes__mutmut_2 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_3'] = x_extract_intensity_minutes__mutmut_3 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_4'] = x_extract_intensity_minutes__mutmut_4 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_5'] = x_extract_intensity_minutes__mutmut_5 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_6'] = x_extract_intensity_minutes__mutmut_6 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_7'] = x_extract_intensity_minutes__mutmut_7 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_8'] = x_extract_intensity_minutes__mutmut_8 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_9'] = x_extract_intensity_minutes__mutmut_9 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_10'] = x_extract_intensity_minutes__mutmut_10 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_11'] = x_extract_intensity_minutes__mutmut_11 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_12'] = x_extract_intensity_minutes__mutmut_12 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_13'] = x_extract_intensity_minutes__mutmut_13 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_14'] = x_extract_intensity_minutes__mutmut_14 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_15'] = x_extract_intensity_minutes__mutmut_15 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_16'] = x_extract_intensity_minutes__mutmut_16 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_17'] = x_extract_intensity_minutes__mutmut_17 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_18'] = x_extract_intensity_minutes__mutmut_18 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_19'] = x_extract_intensity_minutes__mutmut_19 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_20'] = x_extract_intensity_minutes__mutmut_20 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_21'] = x_extract_intensity_minutes__mutmut_21 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_22'] = x_extract_intensity_minutes__mutmut_22 # type: ignore # mutmut generated
mutants_x_extract_intensity_minutes__mutmut['x_extract_intensity_minutes__mutmut_23'] = x_extract_intensity_minutes__mutmut_23 # type: ignore # mutmut generated


EXTRACTORS: dict[str, Any] = {
    "sleep": extract_sleep,
    "sleep_score": extract_sleep_score,
    "hrv": extract_hrv,
    "hrv_weekly": extract_hrv_weekly,
    "body_battery": extract_body_battery,
    "stress_daily": extract_stress_daily,
    "resting_hr": extract_resting_hr,
    "steps": extract_steps,
    "calories": extract_calories,
    "training_readiness": extract_training_readiness,
    "training_status": extract_training_status,
    "vo2max": extract_vo2max,
    "intensity_minutes": extract_intensity_minutes,
}
mutants_x_extract_all__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_extract_all__mutmut)
def extract_all(raw: dict[str, Any]) -> dict[str, ExtractedMetric]:
    """Run every registered extractor against a raw `fetch_day` payload."""
    return {kind: fn(raw) for kind, fn in EXTRACTORS.items()}


def x_extract_all__mutmut_orig(raw: dict[str, Any]) -> dict[str, ExtractedMetric]:
    """Run every registered extractor against a raw `fetch_day` payload."""
    return {kind: fn(raw) for kind, fn in EXTRACTORS.items()}


def x_extract_all__mutmut_1(raw: dict[str, Any]) -> dict[str, ExtractedMetric]:
    """Run every registered extractor against a raw `fetch_day` payload."""
    return {kind: fn(None) for kind, fn in EXTRACTORS.items()}

mutants_x_extract_all__mutmut['_mutmut_orig'] = x_extract_all__mutmut_orig # type: ignore # mutmut generated
mutants_x_extract_all__mutmut['x_extract_all__mutmut_1'] = x_extract_all__mutmut_1 # type: ignore # mutmut generated
