"""Single source of truth for the athlete's default weekly training schedule
(`WEEKLY_SCHEDULE` config), overridden per-day by `DayTypeOverride` rows,
competitions, and logged activities.
"""

from __future__ import annotations

from app.core.config import settings

VALID_DAY_TYPES = {"rest", "gym", "fencing", "double", "competition"}
_WEEKDAY_NAMES = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x__parse_schedule__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x__parse_schedule__mutmut)
def _parse_schedule(raw: str) -> dict[int, str]:
    parts = [p.strip().lower() for p in raw.split(",")]
    if len(parts) != 7:
        raise ValueError(
            f"WEEKLY_SCHEDULE must have exactly 7 comma-separated entries "
            f"(Mon..Sun), got {len(parts)}: {raw!r}"
        )
    invalid = [p for p in parts if p not in VALID_DAY_TYPES]
    if invalid:
        raise ValueError(
            f"WEEKLY_SCHEDULE has invalid day type(s) {invalid}; "
            f"must be one of {sorted(VALID_DAY_TYPES)}"
        )
    return dict(enumerate(parts))


def x__parse_schedule__mutmut_orig(raw: str) -> dict[int, str]:
    parts = [p.strip().lower() for p in raw.split(",")]
    if len(parts) != 7:
        raise ValueError(
            f"WEEKLY_SCHEDULE must have exactly 7 comma-separated entries "
            f"(Mon..Sun), got {len(parts)}: {raw!r}"
        )
    invalid = [p for p in parts if p not in VALID_DAY_TYPES]
    if invalid:
        raise ValueError(
            f"WEEKLY_SCHEDULE has invalid day type(s) {invalid}; "
            f"must be one of {sorted(VALID_DAY_TYPES)}"
        )
    return dict(enumerate(parts))


def x__parse_schedule__mutmut_1(raw: str) -> dict[int, str]:
    parts = None
    if len(parts) != 7:
        raise ValueError(
            f"WEEKLY_SCHEDULE must have exactly 7 comma-separated entries "
            f"(Mon..Sun), got {len(parts)}: {raw!r}"
        )
    invalid = [p for p in parts if p not in VALID_DAY_TYPES]
    if invalid:
        raise ValueError(
            f"WEEKLY_SCHEDULE has invalid day type(s) {invalid}; "
            f"must be one of {sorted(VALID_DAY_TYPES)}"
        )
    return dict(enumerate(parts))


def x__parse_schedule__mutmut_2(raw: str) -> dict[int, str]:
    parts = [p.strip().upper() for p in raw.split(",")]
    if len(parts) != 7:
        raise ValueError(
            f"WEEKLY_SCHEDULE must have exactly 7 comma-separated entries "
            f"(Mon..Sun), got {len(parts)}: {raw!r}"
        )
    invalid = [p for p in parts if p not in VALID_DAY_TYPES]
    if invalid:
        raise ValueError(
            f"WEEKLY_SCHEDULE has invalid day type(s) {invalid}; "
            f"must be one of {sorted(VALID_DAY_TYPES)}"
        )
    return dict(enumerate(parts))


def x__parse_schedule__mutmut_3(raw: str) -> dict[int, str]:
    parts = [p.strip().lower() for p in raw.split(None)]
    if len(parts) != 7:
        raise ValueError(
            f"WEEKLY_SCHEDULE must have exactly 7 comma-separated entries "
            f"(Mon..Sun), got {len(parts)}: {raw!r}"
        )
    invalid = [p for p in parts if p not in VALID_DAY_TYPES]
    if invalid:
        raise ValueError(
            f"WEEKLY_SCHEDULE has invalid day type(s) {invalid}; "
            f"must be one of {sorted(VALID_DAY_TYPES)}"
        )
    return dict(enumerate(parts))


def x__parse_schedule__mutmut_4(raw: str) -> dict[int, str]:
    parts = [p.strip().lower() for p in raw.split("XX,XX")]
    if len(parts) != 7:
        raise ValueError(
            f"WEEKLY_SCHEDULE must have exactly 7 comma-separated entries "
            f"(Mon..Sun), got {len(parts)}: {raw!r}"
        )
    invalid = [p for p in parts if p not in VALID_DAY_TYPES]
    if invalid:
        raise ValueError(
            f"WEEKLY_SCHEDULE has invalid day type(s) {invalid}; "
            f"must be one of {sorted(VALID_DAY_TYPES)}"
        )
    return dict(enumerate(parts))


def x__parse_schedule__mutmut_5(raw: str) -> dict[int, str]:
    parts = [p.strip().lower() for p in raw.split(",")]
    if len(parts) == 7:
        raise ValueError(
            f"WEEKLY_SCHEDULE must have exactly 7 comma-separated entries "
            f"(Mon..Sun), got {len(parts)}: {raw!r}"
        )
    invalid = [p for p in parts if p not in VALID_DAY_TYPES]
    if invalid:
        raise ValueError(
            f"WEEKLY_SCHEDULE has invalid day type(s) {invalid}; "
            f"must be one of {sorted(VALID_DAY_TYPES)}"
        )
    return dict(enumerate(parts))


def x__parse_schedule__mutmut_6(raw: str) -> dict[int, str]:
    parts = [p.strip().lower() for p in raw.split(",")]
    if len(parts) != 8:
        raise ValueError(
            f"WEEKLY_SCHEDULE must have exactly 7 comma-separated entries "
            f"(Mon..Sun), got {len(parts)}: {raw!r}"
        )
    invalid = [p for p in parts if p not in VALID_DAY_TYPES]
    if invalid:
        raise ValueError(
            f"WEEKLY_SCHEDULE has invalid day type(s) {invalid}; "
            f"must be one of {sorted(VALID_DAY_TYPES)}"
        )
    return dict(enumerate(parts))


def x__parse_schedule__mutmut_7(raw: str) -> dict[int, str]:
    parts = [p.strip().lower() for p in raw.split(",")]
    if len(parts) != 7:
        raise ValueError(
            None
        )
    invalid = [p for p in parts if p not in VALID_DAY_TYPES]
    if invalid:
        raise ValueError(
            f"WEEKLY_SCHEDULE has invalid day type(s) {invalid}; "
            f"must be one of {sorted(VALID_DAY_TYPES)}"
        )
    return dict(enumerate(parts))


def x__parse_schedule__mutmut_8(raw: str) -> dict[int, str]:
    parts = [p.strip().lower() for p in raw.split(",")]
    if len(parts) != 7:
        raise ValueError(
            f"WEEKLY_SCHEDULE must have exactly 7 comma-separated entries "
            f"(Mon..Sun), got {len(parts)}: {raw!r}"
        )
    invalid = None
    if invalid:
        raise ValueError(
            f"WEEKLY_SCHEDULE has invalid day type(s) {invalid}; "
            f"must be one of {sorted(VALID_DAY_TYPES)}"
        )
    return dict(enumerate(parts))


def x__parse_schedule__mutmut_9(raw: str) -> dict[int, str]:
    parts = [p.strip().lower() for p in raw.split(",")]
    if len(parts) != 7:
        raise ValueError(
            f"WEEKLY_SCHEDULE must have exactly 7 comma-separated entries "
            f"(Mon..Sun), got {len(parts)}: {raw!r}"
        )
    invalid = [p for p in parts if p in VALID_DAY_TYPES]
    if invalid:
        raise ValueError(
            f"WEEKLY_SCHEDULE has invalid day type(s) {invalid}; "
            f"must be one of {sorted(VALID_DAY_TYPES)}"
        )
    return dict(enumerate(parts))


def x__parse_schedule__mutmut_10(raw: str) -> dict[int, str]:
    parts = [p.strip().lower() for p in raw.split(",")]
    if len(parts) != 7:
        raise ValueError(
            f"WEEKLY_SCHEDULE must have exactly 7 comma-separated entries "
            f"(Mon..Sun), got {len(parts)}: {raw!r}"
        )
    invalid = [p for p in parts if p not in VALID_DAY_TYPES]
    if invalid:
        raise ValueError(
            None
        )
    return dict(enumerate(parts))


def x__parse_schedule__mutmut_11(raw: str) -> dict[int, str]:
    parts = [p.strip().lower() for p in raw.split(",")]
    if len(parts) != 7:
        raise ValueError(
            f"WEEKLY_SCHEDULE must have exactly 7 comma-separated entries "
            f"(Mon..Sun), got {len(parts)}: {raw!r}"
        )
    invalid = [p for p in parts if p not in VALID_DAY_TYPES]
    if invalid:
        raise ValueError(
            f"WEEKLY_SCHEDULE has invalid day type(s) {invalid}; "
            f"must be one of {sorted(None)}"
        )
    return dict(enumerate(parts))


def x__parse_schedule__mutmut_12(raw: str) -> dict[int, str]:
    parts = [p.strip().lower() for p in raw.split(",")]
    if len(parts) != 7:
        raise ValueError(
            f"WEEKLY_SCHEDULE must have exactly 7 comma-separated entries "
            f"(Mon..Sun), got {len(parts)}: {raw!r}"
        )
    invalid = [p for p in parts if p not in VALID_DAY_TYPES]
    if invalid:
        raise ValueError(
            f"WEEKLY_SCHEDULE has invalid day type(s) {invalid}; "
            f"must be one of {sorted(VALID_DAY_TYPES)}"
        )
    return dict(None)


def x__parse_schedule__mutmut_13(raw: str) -> dict[int, str]:
    parts = [p.strip().lower() for p in raw.split(",")]
    if len(parts) != 7:
        raise ValueError(
            f"WEEKLY_SCHEDULE must have exactly 7 comma-separated entries "
            f"(Mon..Sun), got {len(parts)}: {raw!r}"
        )
    invalid = [p for p in parts if p not in VALID_DAY_TYPES]
    if invalid:
        raise ValueError(
            f"WEEKLY_SCHEDULE has invalid day type(s) {invalid}; "
            f"must be one of {sorted(VALID_DAY_TYPES)}"
        )
    return dict(enumerate(None))

mutants_x__parse_schedule__mutmut['_mutmut_orig'] = x__parse_schedule__mutmut_orig # type: ignore # mutmut generated
mutants_x__parse_schedule__mutmut['x__parse_schedule__mutmut_1'] = x__parse_schedule__mutmut_1 # type: ignore # mutmut generated
mutants_x__parse_schedule__mutmut['x__parse_schedule__mutmut_2'] = x__parse_schedule__mutmut_2 # type: ignore # mutmut generated
mutants_x__parse_schedule__mutmut['x__parse_schedule__mutmut_3'] = x__parse_schedule__mutmut_3 # type: ignore # mutmut generated
mutants_x__parse_schedule__mutmut['x__parse_schedule__mutmut_4'] = x__parse_schedule__mutmut_4 # type: ignore # mutmut generated
mutants_x__parse_schedule__mutmut['x__parse_schedule__mutmut_5'] = x__parse_schedule__mutmut_5 # type: ignore # mutmut generated
mutants_x__parse_schedule__mutmut['x__parse_schedule__mutmut_6'] = x__parse_schedule__mutmut_6 # type: ignore # mutmut generated
mutants_x__parse_schedule__mutmut['x__parse_schedule__mutmut_7'] = x__parse_schedule__mutmut_7 # type: ignore # mutmut generated
mutants_x__parse_schedule__mutmut['x__parse_schedule__mutmut_8'] = x__parse_schedule__mutmut_8 # type: ignore # mutmut generated
mutants_x__parse_schedule__mutmut['x__parse_schedule__mutmut_9'] = x__parse_schedule__mutmut_9 # type: ignore # mutmut generated
mutants_x__parse_schedule__mutmut['x__parse_schedule__mutmut_10'] = x__parse_schedule__mutmut_10 # type: ignore # mutmut generated
mutants_x__parse_schedule__mutmut['x__parse_schedule__mutmut_11'] = x__parse_schedule__mutmut_11 # type: ignore # mutmut generated
mutants_x__parse_schedule__mutmut['x__parse_schedule__mutmut_12'] = x__parse_schedule__mutmut_12 # type: ignore # mutmut generated
mutants_x__parse_schedule__mutmut['x__parse_schedule__mutmut_13'] = x__parse_schedule__mutmut_13 # type: ignore # mutmut generated
mutants_x_weekly_schedule__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_weekly_schedule__mutmut)
def weekly_schedule() -> dict[int, str]:
    """Weekday (0=Mon..6=Sun) -> default day_type, parsed from config."""
    return _parse_schedule(settings.WEEKLY_SCHEDULE)


def x_weekly_schedule__mutmut_orig() -> dict[int, str]:
    """Weekday (0=Mon..6=Sun) -> default day_type, parsed from config."""
    return _parse_schedule(settings.WEEKLY_SCHEDULE)


def x_weekly_schedule__mutmut_1() -> dict[int, str]:
    """Weekday (0=Mon..6=Sun) -> default day_type, parsed from config."""
    return _parse_schedule(None)

mutants_x_weekly_schedule__mutmut['_mutmut_orig'] = x_weekly_schedule__mutmut_orig # type: ignore # mutmut generated
mutants_x_weekly_schedule__mutmut['x_weekly_schedule__mutmut_1'] = x_weekly_schedule__mutmut_1 # type: ignore # mutmut generated


def day_type_for_weekday(weekday: int) -> str:
    return weekly_schedule()[weekday]
mutants_x_is_gym_day__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_is_gym_day__mutmut)
def is_gym_day(weekday: int) -> bool:
    return weekly_schedule().get(weekday) == "gym"


def x_is_gym_day__mutmut_orig(weekday: int) -> bool:
    return weekly_schedule().get(weekday) == "gym"


def x_is_gym_day__mutmut_1(weekday: int) -> bool:
    return weekly_schedule().get(None) == "gym"


def x_is_gym_day__mutmut_2(weekday: int) -> bool:
    return weekly_schedule().get(weekday) != "gym"


def x_is_gym_day__mutmut_3(weekday: int) -> bool:
    return weekly_schedule().get(weekday) == "XXgymXX"


def x_is_gym_day__mutmut_4(weekday: int) -> bool:
    return weekly_schedule().get(weekday) == "GYM"

mutants_x_is_gym_day__mutmut['_mutmut_orig'] = x_is_gym_day__mutmut_orig # type: ignore # mutmut generated
mutants_x_is_gym_day__mutmut['x_is_gym_day__mutmut_1'] = x_is_gym_day__mutmut_1 # type: ignore # mutmut generated
mutants_x_is_gym_day__mutmut['x_is_gym_day__mutmut_2'] = x_is_gym_day__mutmut_2 # type: ignore # mutmut generated
mutants_x_is_gym_day__mutmut['x_is_gym_day__mutmut_3'] = x_is_gym_day__mutmut_3 # type: ignore # mutmut generated
mutants_x_is_gym_day__mutmut['x_is_gym_day__mutmut_4'] = x_is_gym_day__mutmut_4 # type: ignore # mutmut generated
mutants_x_schedule_description__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_schedule_description__mutmut)
def schedule_description() -> str:
    """Human-readable schedule text, e.g. for LLM prompt injection."""
    sched = weekly_schedule()
    return ", ".join(f"{_WEEKDAY_NAMES[i]}={sched[i]}" for i in range(7))


def x_schedule_description__mutmut_orig() -> str:
    """Human-readable schedule text, e.g. for LLM prompt injection."""
    sched = weekly_schedule()
    return ", ".join(f"{_WEEKDAY_NAMES[i]}={sched[i]}" for i in range(7))


def x_schedule_description__mutmut_1() -> str:
    """Human-readable schedule text, e.g. for LLM prompt injection."""
    sched = None
    return ", ".join(f"{_WEEKDAY_NAMES[i]}={sched[i]}" for i in range(7))


def x_schedule_description__mutmut_2() -> str:
    """Human-readable schedule text, e.g. for LLM prompt injection."""
    sched = weekly_schedule()
    return ", ".join(None)


def x_schedule_description__mutmut_3() -> str:
    """Human-readable schedule text, e.g. for LLM prompt injection."""
    sched = weekly_schedule()
    return "XX, XX".join(f"{_WEEKDAY_NAMES[i]}={sched[i]}" for i in range(7))


def x_schedule_description__mutmut_4() -> str:
    """Human-readable schedule text, e.g. for LLM prompt injection."""
    sched = weekly_schedule()
    return ", ".join(f"{_WEEKDAY_NAMES[i]}={sched[i]}" for i in range(None))


def x_schedule_description__mutmut_5() -> str:
    """Human-readable schedule text, e.g. for LLM prompt injection."""
    sched = weekly_schedule()
    return ", ".join(f"{_WEEKDAY_NAMES[i]}={sched[i]}" for i in range(8))

mutants_x_schedule_description__mutmut['_mutmut_orig'] = x_schedule_description__mutmut_orig # type: ignore # mutmut generated
mutants_x_schedule_description__mutmut['x_schedule_description__mutmut_1'] = x_schedule_description__mutmut_1 # type: ignore # mutmut generated
mutants_x_schedule_description__mutmut['x_schedule_description__mutmut_2'] = x_schedule_description__mutmut_2 # type: ignore # mutmut generated
mutants_x_schedule_description__mutmut['x_schedule_description__mutmut_3'] = x_schedule_description__mutmut_3 # type: ignore # mutmut generated
mutants_x_schedule_description__mutmut['x_schedule_description__mutmut_4'] = x_schedule_description__mutmut_4 # type: ignore # mutmut generated
mutants_x_schedule_description__mutmut['x_schedule_description__mutmut_5'] = x_schedule_description__mutmut_5 # type: ignore # mutmut generated
